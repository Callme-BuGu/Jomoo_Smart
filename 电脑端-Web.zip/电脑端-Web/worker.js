export default {
  async fetch(request) {
    return new Response(`
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>九牧马桶控制</title>
<link rel="icon" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'%3E%3Crect width='64' height='64' rx='14' fill='%23000'/%3E%3Ctext x='32' y='44' font-size='34' font-family='sans-serif' fill='%23fff' text-anchor='middle'%3E%E4%B9%9D%3C/text%3E%3C/svg%3E">
<style>
/* ===== X 风格 token（跟随系统深浅色） ===== */
:root {
  --bg: #ffffff;
  --fg: #0f1419;
  --gray: #536471;
  --border: #e7e7e8;
  --hover: #f7f7f8;
  --btn: #0f1419;
  --btn-text: #ffffff;
  --sel: #0f1419;
}
@media (prefers-color-scheme: dark) {
  :root {
    --bg: #000000;
    --fg: #e7e9ea;
    --gray: #71767b;
    --border: #2f3336;
    --hover: #16181c;
    --btn: #e7e9ea;
    --btn-text: #000000;
    --sel: #e7e9ea;
  }
}
* { margin: 0; padding: 0; box-sizing: border-box; }
html, body { height: 100%; }
body {
  background: var(--bg); color: var(--fg);
  font: 15px/1.5 -apple-system, BlinkMacSystemFont, "Segoe UI", "PingFang SC", "Microsoft YaHei", sans-serif;
  display: flex; flex-direction: column;
}
button { font: inherit; border: none; background: none; color: inherit; cursor: pointer; }

/* ===== 顶部状态条 ===== */
.topbar {
  display: flex; align-items: center; justify-content: space-between;
  padding: 10px 16px; border-bottom: 1px solid var(--border);
  position: sticky; top: 0; background: var(--bg); z-index: 20;
}
.topbar .title { font-size: 17px; font-weight: 800; letter-spacing: .2px; }
.conn {
  display: inline-flex; align-items: center; gap: 6px;
  font-size: 13px; color: var(--gray); font-weight: 600;
}
.conn .dot { width: 9px; height: 9px; border-radius: 50%; background: var(--gray); }
.conn.ok .dot { background: #17bf63; }
.conn.ok { color: var(--fg); }
.banner {
  display: none; font-size: 13px; color: var(--fg);
  background: var(--hover); padding: 8px 16px; border-bottom: 1px solid var(--border);
}
.banner.show { display: block; }

/* ===== 布局 ===== */
.layout { flex: 1; display: flex; min-height: 0; }
.sidenav {
  display: none; width: 210px; flex-shrink: 0;
  border-right: 1px solid var(--border);
  flex-direction: column; gap: 2px; padding: 14px 10px; overflow-y: auto;
}
.sidenav .nav-item {
  display: flex; align-items: center; gap: 14px;
  padding: 11px 14px; border-radius: 999px; font-size: 17px; font-weight: 600;
  color: var(--gray); text-align: left;
}
.sidenav .nav-item:hover { background: var(--hover); }
.sidenav .nav-item.active { color: var(--fg); font-weight: 800; }
.sidenav .nav-item svg { width: 24px; height: 24px; flex-shrink: 0; }

main {
  flex: 1; min-width: 0; overflow-y: auto;
  padding: 14px 16px 96px;
}
main .page { max-width: 640px; margin: 0 auto; }

/* ===== 卡片（X 平直风格） ===== */
.card { margin-bottom: 14px; }
.card-title {
  font-size: 13px; font-weight: 700; color: var(--gray);
  text-transform: none; letter-spacing: .3px; margin-bottom: 8px;
}
.card-body { border: 1px solid var(--border); border-radius: 16px; padding: 14px; }

/* ===== 按钮 ===== */
.btn {
  display: inline-flex; align-items: center; justify-content: center;
  min-height: 44px; padding: 0 18px; border-radius: 999px;
  font-weight: 700; font-size: 15px; white-space: nowrap;
  background: var(--hover); color: var(--fg);
  transition: opacity .15s, background .15s;
}
.btn:active { opacity: .7; }
.btn.primary { background: var(--btn); color: var(--btn-text); }
.btn.outline { background: transparent; border: 1px solid var(--border); color: var(--fg); }
.btn.danger { background: transparent; border: 1px solid var(--border); color: #e0245e; }
.btn:disabled { opacity: .4; cursor: not-allowed; }
.btn.sel { background: var(--sel); color: var(--btn-text); border-color: transparent; }
.btn.sel.danger { color: #fff; background: #e0245e; }

.grid { display: grid; gap: 8px; }
.grid-2 { grid-template-columns: repeat(2, 1fr); }
.grid-3 { grid-template-columns: repeat(3, 1fr); }
.grid-4 { grid-template-columns: repeat(4, 1fr); }
.row { display: flex; align-items: center; gap: 10px; }
.row .grow { flex: 1; min-width: 0; }

/* ===== 状态项 ===== */
.status-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 10px 14px; }
.st { display: flex; justify-content: space-between; align-items: baseline; gap: 8px; font-size: 14px; }
.st .k { color: var(--gray); font-size: 13px; }
.st .v { font-weight: 700; }

/* ===== 日志 ===== */
.logbox {
  border: 1px solid var(--border); border-radius: 16px; padding: 12px;
  font-family: "SF Mono", Consolas, "Courier New", monospace;
  font-size: 12px; line-height: 1.6; white-space: pre-wrap; word-break: break-all;
  min-height: 120px; max-height: 340px; overflow-y: auto; color: var(--fg);
}
.log-empty { color: var(--gray); }

/* ===== 手机底部导航（X 风格） ===== */
.bottomnav {
  display: flex; position: fixed; left: 0; right: 0; bottom: 0;
  border-top: 1px solid var(--border); background: var(--bg);
  padding-bottom: env(safe-area-inset-bottom); z-index: 30;
}
.bottomnav .nav-item {
  flex: 1; display: flex; flex-direction: column; align-items: center;
  gap: 3px; padding: 9px 0 7px; color: var(--gray); font-size: 11px; font-weight: 600;
}
.bottomnav .nav-item svg { width: 23px; height: 23px; }
.bottomnav .nav-item.active { color: var(--fg); font-weight: 800; }

/* ===== 桌面（≥769px）：左导航，无底栏，双列 ===== */
@media (min-width: 769px) {
  .sidenav { display: flex; }
  .bottomnav { display: none; }
  main { padding: 20px 28px 40px; }
  main .page { max-width: 920px; }
  .desk-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 14px; align-items: start; }
}
</style>
</head>
<body>

<!-- ===== 顶部状态条 ===== -->
<header class="topbar">
  <span class="title">九牧马桶控制</span>
  <span class="conn" id="conn"><span class="dot"></span><span id="connText">未连接</span></span>
</header>
<div class="banner" id="bleBanner"></div>

<div class="layout">

  <!-- ===== 桌面左导航 ===== -->
  <nav class="sidenav" id="sidenav">
    <button class="nav-item active" data-page="control">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M12 3v5"/><circle cx="12" cy="14" r="6"/></svg>
      <span>控制</span>
    </button>
    <button class="nav-item" data-page="settings">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="4"/><path d="M12 2v4M12 18v4M2 12h4M18 12h4"/></svg>
      <span>设置</span>
    </button>
    <button class="nav-item" data-page="log">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><rect x="4" y="4" width="16" height="16" rx="2"/><path d="M8 8h8M8 12h8M8 16h4"/></svg>
      <span>日志</span>
    </button>
  </nav>

  <!-- ===== 主内容 ===== -->
  <main>
    <!-- 控制页 -->
    <section class="page" id="page-control">
      <div class="desk-grid">
        <div>
          <!-- 连接卡 -->
          <div class="card">
            <div class="card-title">连接</div>
            <div class="card-body">
              <div class="row" style="margin-bottom:12px">
                <button class="btn primary grow" id="btnScan">扫描并连接马桶</button>
                <button class="btn outline" id="btnDisc" disabled>断开</button>
              </div>
              <div style="font-size:13px;color:var(--gray)" id="connHint">
                点击按钮后选择「JOMOO」开头设备进行连接
              </div>
            </div>
          </div>
          <!-- 控制卡 -->
          <div class="card">
            <div class="card-title">控制</div>
            <div class="card-body">
              <div class="grid grid-2" style="margin-bottom:8px">
                <button class="btn primary" data-cmd="flushL">大冲</button>
                <button class="btn primary" data-cmd="flushS">小冲</button>
              </div>
              <div class="grid grid-3">
                <button class="btn outline" data-cmd="coverOpen">开盖</button>
                <button class="btn outline" data-cmd="coverClose">关盖</button>
                <button class="btn outline" data-cmd="ringOpen">翻圈开</button>
              </div>
              <div class="grid grid-3" style="margin-top:8px">
                <button class="btn outline" data-cmd="ringClose">翻圈关</button>
                <span></span><span></span>
              </div>
            </div>
          </div>
        </div>
        <div>
          <!-- 状态卡 -->
          <div class="card">
            <div class="card-title">设备状态</div>
            <div class="card-body">
              <div class="status-grid">
                <div class="st"><span class="k">工作状态</span><span class="v" id="stWs">-</span></div>
                <div class="st"><span class="k">盖板</span><span class="v" id="stCover">-</span></div>
                <div class="st"><span class="k">座圈</span><span class="v" id="stRing">-</span></div>
                <div class="st"><span class="k">着座</span><span class="v" id="stSeat">-</span></div>
                <div class="st"><span class="k">翻盖中</span><span class="v" id="stMc">-</span></div>
                <div class="st"><span class="k">翻圈中</span><span class="v" id="stMr">-</span></div>
                <div class="st"><span class="k">座温档</span><span class="v" id="stTemp">-</span></div>
                <div class="st"><span class="k">自动冲刷</span><span class="v" id="stAf">-</span></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- 设置页 -->
    <section class="page" id="page-settings" hidden>
      <div class="card">
        <div class="card-title">设置</div>
        <div class="card-body">
          <div class="row" style="margin-bottom:14px">
            <span class="grow" style="font-weight:700">泡沫盾</span>
            <button class="btn outline" id="foamOff">关</button>
            <button class="btn outline" id="foamOn">开</button>
          </div>
          <div class="row" style="margin-bottom:18px">
            <span class="grow" style="font-weight:700">预湿润</span>
            <button class="btn outline" id="prewetOff">关</button>
            <button class="btn outline" id="prewetOn">开</button>
          </div>
          <div style="font-weight:700;margin-bottom:10px">座圈加热（0 档 = 关）</div>
          <div class="grid grid-4">
            <button class="btn outline" data-seat="0">0</button>
            <button class="btn outline" data-seat="1">1</button>
            <button class="btn outline" data-seat="2">2</button>
            <button class="btn outline" data-seat="3">3</button>
          </div>
        </div>
      </div>
    </section>

    <!-- 日志页 -->
    <section class="page" id="page-log" hidden>
      <div class="card">
        <div class="card-title">通信日志</div>
        <div class="card-body">
          <div class="logbox" id="logbox"><span class="log-empty">暂无日志。连接后操作会自动记录。</span></div>
        </div>
      </div>
    </section>
  </main>
</div>

<!-- ===== 手机底部导航 ===== -->
<nav class="bottomnav" id="bottomnav">
  <button class="nav-item active" data-page="control">
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M12 3v5"/><circle cx="12" cy="14" r="6"/></svg>
    <span>控制</span>
  </button>
  <button class="nav-item" data-page="settings">
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="4"/><path d="M12 2v4M12 18v4M2 12h4M18 12h4"/></svg>
    <span>设置</span>
  </button>
  <button class="nav-item" data-page="log">
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><rect x="4" y="4" width="16" height="16" rx="2"/><path d="M8 8h8M8 12h8M8 16h4"/></svg>
    <span>日志</span>
  </button>
</nav>

<script>
/* ================= 九牧 SQ7650 Techramic FC 协议 ================= */
const SRV = '0000ffe0-0000-1000-8000-00805f9b34fb';
const CHR = '0000ffe1-0000-1000-8000-00805f9b34fb';

function buildCommand(cmd, val) {
  const f = new Uint8Array([0xFC, 0, 0x01, 0, 0, 0, cmd, val, 0xFC]);
  let s = 0; for (let i = 2; i <= f.length - 2; i++) s += f[i];
  f[1] = s & 0xFF; return f;
}
function buildSet40(sub, on) {
  const f = new Uint8Array([0xFC, 0, 0x01, 0, 0, 0, 0x40, sub, on, 0xFC]);
  let s = 0; for (let i = 2; i <= f.length - 2; i++) s += f[i];
  f[1] = s & 0xFF; return f;
}
function hex(b) { return Array.from(b).map(x => x.toString(16).toUpperCase().padStart(2, '0')).join(' '); }

const WS_NAMES = { 1: '休眠中', 2: '就绪/工作中', 16: '自清洁', 17: '预湿润', 31: '未就绪' };
function parseStatus(d) {
  if (!d || d.length < 18) return null;
  const ws = d[7] & 0xFF;
  const cover = (d[11] >> 3) & 1, ring = (d[11] >> 2) & 1, seat = d[11] & 1;
  const mc = (d[13] >> 4) & 1, mr = (d[13] >> 5) & 1;
  const st = d[17] & 0x0F, af = (d[17] >> 7) & 1;
  return {
    ws: WS_NAMES[ws] || ('状态' + ws),
    cover: cover ? '开' : '关', ring: ring ? '开' : '关', seat: seat ? '有人' : '无人',
    mc: mc ? '是' : '否', mr: mr ? '是' : '否',
    temp: st, af: af ? '开' : '关'
  };
}

/* ================= 状态 ================= */
let device = null, server = null, char = null, pollingId = null;
let connected = false;
let lastStatus = '';

const $ = id => document.getElementById(id);
const connEl = $('conn'), connText = $('connText'), btnScan = $('btnScan'), btnDisc = $('btnDisc');

function setConn(ok, text) {
  connEl.classList.toggle('ok', ok);
  connText.textContent = text;
  btnDisc.disabled = !ok;
}

/* ================= 日志 ================= */
function logLine(s) {
  const box = $('logbox');
  if (box.firstElementChild && box.firstElementChild.classList.contains('log-empty')) box.innerHTML = '';
  const t = new Date().toLocaleTimeString('zh-CN', { hour12: false });
  box.textContent = (box.textContent ? box.textContent + '\\n' : '') + '[' + t + '] ' + s;
  box.scrollTop = box.scrollHeight;
}

/* ================= BLE ================= */
function bleSupported() {
  return navigator.bluetooth !== undefined;
}

async function connect() {
  if (!bleSupported()) return;
  if (connected) return;
  try {
    setConn(false, '连接中…');
    btnScan.disabled = true;
    device = await navigator.bluetooth.requestDevice({
      filters: [{ services: [SRV] }],
      optionalServices: [SRV]
    });
    server = await device.gatt.connect();
    const service = await server.getPrimaryService(SRV);
    char = await service.getCharacteristic(CHR);
    await char.startNotifications();
    char.addEventListener('characteristicvaluechanged', onRx);
    connected = true;
    setConn(true, '已连接 ' + (device.name || device.id));
    logLine('已连接 ' + (device.name || '马桶'));
    startPolling();
    send(buildCommand(0x11, 0), false);
  } catch (e) {
    connected = false;
    setConn(false, '未连接');
    if (e && e.name === 'NotFoundError') logLine('未选择设备或没有发现马桶');
    else logLine('连接失败：' + (e && e.message ? e.message : e));
  } finally {
    btnScan.disabled = false;
  }
}

function disconnect() {
  stopPolling();
  if (device && device.gatt.connected) { try { device.gatt.disconnect(); } catch (e) {} }
  connected = false; device = null; server = null; char = null;
  setConn(false, '未连接');
  logLine('已断开');
}

/* 发送帧；quiet=true 不记日志（轮询） */
async function send(frame, quiet, tag) {
  if (!connected || !char) return;
  try {
    await char.writeValueWithoutResponse(frame);
    if (!quiet) logLine((tag || '命令') + ' TX: ' + hex(frame));
  } catch (e) {
    logLine('发送失败：' + (e && e.message ? e.message : e));
  }
}

function onRx(ev) {
  const d = new Uint8Array(ev.target.value.buffer);
  if (d.length === 0 || d[0] !== 0xFC) return;
  if (d.length >= 18 && d[6] === 0x30) {
    const st = parseStatus(d);
    if (st) {
      const key = JSON.stringify(st);
      if (key !== lastStatus) {
        lastStatus = key;
        renderStatus(st);
        logLine('状态更新 RX: ' + hex(d));
      }
    }
  }
}

function renderStatus(st) {
  $('stWs').textContent = st.ws;
  $('stCover').textContent = st.cover;
  $('stRing').textContent = st.ring;
  $('stSeat').textContent = st.seat;
  $('stMc').textContent = st.mc;
  $('stMr').textContent = st.mr;
  $('stTemp').textContent = st.temp;
  $('stAf').textContent = st.af;
}

/* 3 秒状态轮询（静默） */
function startPolling() {
  stopPolling();
  pollingId = setInterval(() => {
    if (connected && char) send(buildCommand(0x11, 0), true);
  }, 3000);
}
function stopPolling() {
  if (pollingId) { clearInterval(pollingId); pollingId = null; }
}

/* ================= 命令映射 ================= */
const CMDS = {
  flushL:  () => send(buildCommand(0x35, 2), false, '大冲'),
  flushS:  () => send(buildCommand(0x35, 1), false, '小冲'),
  coverOpen:  () => send(buildCommand(0x33, 1), false, '开盖'),
  coverClose: () => send(buildCommand(0x33, 0), false, '关盖'),
  ringOpen:   () => send(buildCommand(0x34, 1), false, '翻圈开'),
  ringClose:  () => send(buildCommand(0x34, 0), false, '翻圈关'),
};

/* ================= 视图切换（PC 左导航 / 手机底栏共用） ================= */
function switchPage(name) {
  ['control', 'settings', 'log'].forEach(p => {
    $('page-' + p).hidden = p !== name;
  });
  document.querySelectorAll('.nav-item[data-page]').forEach(n => {
    n.classList.toggle('active', n.dataset.page === name);
  });
}

/* ================= 选中态（设置按钮） ================= */
function markSel(group, btn) {
  document.querySelectorAll(group).forEach(b => b.classList.remove('sel'));
  btn.classList.add('sel');
}

/* ================= 绑定事件 ================= */
btnScan.addEventListener('click', connect);
btnDisc.addEventListener('click', disconnect);

document.querySelectorAll('[data-cmd]').forEach(b => {
  b.addEventListener('click', () => CMDS[b.dataset.cmd]());
});

document.querySelectorAll('.nav-item[data-page]').forEach(n => {
  n.addEventListener('click', () => switchPage(n.dataset.page));
});

/* 泡沫盾 / 预湿润 / 座温 */
const foamOff = $('foamOff'), foamOn = $('foamOn');
foamOff.addEventListener('click', () => { send(buildSet40(12, 0), false, '泡沫盾关'); markSel('[id^="foam"]', foamOff); });
foamOn.addEventListener('click',  () => { send(buildSet40(12, 1), false, '泡沫盾开'); markSel('[id^="foam"]', foamOn); });
const prewetOff = $('prewetOff'), prewetOn = $('prewetOn');
prewetOff.addEventListener('click', () => { send(buildSet40(18, 0), false, '预湿润关'); markSel('[id^="prewet"]', prewetOff); });
prewetOn.addEventListener('click',  () => { send(buildSet40(18, 1), false, '预湿润开'); markSel('[id^="prewet"]', prewetOn); });
document.querySelectorAll('[data-seat]').forEach(b => {
  b.addEventListener('click', () => {
    const lvl = parseInt(b.dataset.seat, 10);
    send(buildCommand(0x3C, lvl), false, '座圈加热 ' + lvl + ' 档');
    markSel('[data-seat]', b);
  });
});

/* ================= 初始化 ================= */
(function init() {
  if (!bleSupported()) {
    $('bleBanner').classList.add('show');
    $('bleBanner').textContent = '当前环境不支持蓝牙：网页需在 HTTPS 或 localhost 下打开才能连接马桶（直接双击本地文件不行）。UI 功能可正常浏览。';
    btnScan.disabled = true;
    btnScan.textContent = '环境不支持蓝牙';
  }
  switchPage('control');
})();
</script>
</body>
</html>

`, {
      headers: { 'Content-Type': 'text/html; charset=utf-8' }
    });
  }
};
